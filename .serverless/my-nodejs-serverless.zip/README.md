# learningnodeserverless
learning node js serverless lambda dynamo db
